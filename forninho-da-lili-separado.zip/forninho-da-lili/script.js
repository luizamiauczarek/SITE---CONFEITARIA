/* ====== CONFIGURE AQUI ====== */
const WHATSAPP="5519999999999"; // 55 + DDD + número, só dígitos
const NOME="Forninho da Lili";
const PIX={nome:"[Nome completo da titular]",chave:"[chave pix da cliente]"};
const ENDERECO="Praça da Sé, São Paulo, SP"; // trocar pelo endereço real
const FOTOS=[
{s:"fotos/saquinho-biscoitos.jpg",a:"Saquinho de biscoitos amanteigados com laço rosa e o selo do Forninho da Lili"},
{s:"fotos/biscoitos-goiabada.jpg",a:"Biscoitinhos de goiabada em uma bandeja de madeira em formato de coração, ao lado de uma xícara de café"},
{s:"fotos/brigadeiros-aranha.jpg",a:"Brigadeiros vermelhos decorados com teia de aranha dourada, edição especial"}];
const FOTO_CASA=""; // ex.: "fotos/fachada.jpg"
const AVISO="Produzido em cozinha que também manipula glúten, leite, ovos e nozes. Em caso de alergia, fale com a confeiteira antes de pedir.";
const PRODUTOS=[
{id:1,n:"Brigadeiro gourmet",c:"Docinhos",p:3.5,e:"🍫",pop:30,d:"Brigadeiro cremoso de chocolate belga.",i:"Chocolate belga, creme de leite, manteiga, granulado de chocolate",g:0,a:["Leite","Soja"],img:""},
{id:2,n:"Beijinho de coco",c:"Docinhos",p:3.5,e:"🥥",pop:18,d:"Clássico de coco com toque de cravo.",i:"Leite condensado, coco ralado, manteiga, cravo",g:0,a:["Leite","Coco"],img:""},
{id:3,n:"Casadinho",c:"Docinhos",p:4,e:"🤎",pop:14,d:"Brigadeiro branco e de chocolate.",i:"Chocolate branco e ao leite, creme de leite, manteiga",g:0,a:["Leite","Soja"],img:""},
{id:4,n:"Trufa de maracujá",c:"Docinhos",p:6,e:"💛",pop:20,d:"Ganache de chocolate branco e maracujá.",i:"Chocolate branco, polpa de maracujá, creme de leite",g:0,a:["Leite","Soja"],img:""},
{id:5,n:"Brownie",c:"Sobremesas",p:9,e:"🍪",pop:40,d:"Úmido por dentro, casquinha crocante.",i:"Chocolate meio amargo, ovos, farinha de trigo, manteiga, açúcar, nozes",g:1,a:["Ovo","Leite","Nozes"],img:""},
{id:6,n:"Bolo no pote",c:"Sobremesas",p:12,e:"🍮",pop:25,d:"Camadas de massa e recheio cremoso (ninho com morango ou chocolate).",i:"Farinha de trigo, ovos, leite, leite em pó, morango, açúcar",g:1,a:["Ovo","Leite"],img:""},
{id:7,n:"Mini bolo de cenoura",c:"Bolos",p:35,e:"🥕",pop:22,d:"Serve 4 fatias, com cobertura de chocolate.",i:"Cenoura, ovos, óleo de girassol, farinha de trigo, açúcar, chocolate",g:1,a:["Ovo","Leite"],img:""},
{id:8,n:"Mini bolo de limão",c:"Bolos",p:38,e:"🍋",pop:16,d:"Serve 4 fatias, com glacê cítrico.",i:"Limão siciliano, ovos, farinha de trigo, manteiga, açúcar",g:1,a:["Ovo","Leite"],img:""}];
/* ============================ */
const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s),R=n=>"R$ "+n.toFixed(2).replace(".",","),P=i=>PRODUTOS.find(p=>p.id==i);
const L=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},S=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
let cart=L("cart",{}),pop=L("pop",{}),fs=L("fs",100),root=document.documentElement;
function tema(t){t==="auto"?root.removeAttribute("data-theme"):root.setAttribute("data-theme",t);$("#th").value=t;S("tema",t)}
tema(L("tema","auto"));$("#th").onchange=e=>tema(e.target.value);
function tam(v){fs=Math.max(85,Math.min(150,v));root.style.fontSize=fs+"%";S("fs",fs)}tam(fs);$("#fm").onclick=()=>tam(fs-10);$("#fp").onclick=()=>tam(fs+10);
const wl=m=>"https://wa.me/"+WHATSAPP+"?text="+encodeURIComponent(m);
$("#fb").href=$("#fw").href=wl("Olá! Vim pelo site do "+NOME+" e gostaria de tirar uma dúvida.");
$("#pn").textContent=PIX.nome;$("#pk").textContent=PIX.chave;$$(".pn").forEach(x=>x.textContent=PIX.nome);$$(".pk").forEach(x=>x.textContent=PIX.chave);
$$("[data-copy]").forEach(b=>b.onclick=async()=>{let ok=1;try{await navigator.clipboard.writeText(PIX.chave)}catch(e){ok=0}$("#pm").textContent=$("#pm2").textContent=ok?"Chave copiada!":"Não foi possível copiar. Selecione a chave e copie.";});
$("#ad").textContent=$("#fad").textContent=ENDERECO;
$("#mp").src="https://www.google.com/maps?q="+encodeURIComponent(ENDERECO)+"&t=k&z=19&output=embed";
$("#ml").href="https://www.google.com/maps?q="+encodeURIComponent(ENDERECO)+"&t=k";
$("#fa").innerHTML=FOTO_CASA?`<img src="${FOTO_CASA}" alt="Fachada do local de retirada">`:`<div><div style="font-size:4rem" aria-hidden="true">🏡</div><p>Foto da fachada da casa<br><small>para você reconhecer o local na retirada</small></p></div>`;
const cats=[...new Set(PRODUTOS.map(p=>p.c))];
$("#cats").innerHTML=cats.map(c=>`<a class="cat" href="#c-${c}"><div><h3>${c}</h3><small>${PRODUTOS.filter(p=>p.c===c).length} itens</small></div><span aria-hidden="true">${PRODUTOS.find(p=>p.c===c).e}</span></a>`).join("");
const card=(p,tag)=>`<article class="p"><div class="pi">${p.img?`<img src="${p.img}" alt="${p.n}" loading="lazy">`:`<span aria-hidden="true">${p.e}</span>`}${tag?`<span class="tag">${tag}</span>`:""}</div><div class="pb"><h3>${p.n}</h3><p>${p.d}</p><div class="bd"><span>${p.g?"Contém glúten":"Sem glúten na receita"}</span></div><div class="pr"><b>${R(p.p)}</b><span><button class="sm" data-v="${p.id}">Detalhes</button> <button class="sm f" data-a="${p.id}">Adicionar</button></span></div></div></article>`;
function vitrine(){const top=[...PRODUTOS].sort((a,b)=>(b.pop+(pop[b.id]||0))-(a.pop+(pop[a.id]||0))).slice(0,3);
$("#pops").innerHTML=`<section class="catsec" id="c-pop"><div class="wrap"><h2>Mais pedidos</h2><div class="grid">${top.map((p,i)=>card(p,"#"+(i+1)+" mais pedido")).join("")}</div></div></section>`;
$("#secs").innerHTML=cats.map(c=>`<section class="catsec" id="c-${c}"><div class="wrap"><h2>${c}</h2><div class="grid">${PRODUTOS.filter(p=>p.c===c).map(p=>card(p)).join("")}</div></div></section>`).join("");
$$("[data-a]").forEach(b=>b.onclick=()=>{add(b.dataset.a);b.textContent="Adicionado ✓";setTimeout(()=>b.textContent="Adicionar",1000)});
$$("[data-v]").forEach(b=>b.onclick=()=>det(b.dataset.v))}
function add(i,n=1){cart[i]=(cart[i]||0)+n;draw()}
function det(i){const p=P(i);$("#dn").textContent=p.n;$("#db").innerHTML=`<p>${p.d}</p><p><b>Ingredientes:</b> ${p.i}.</p><div class="bd"><span>${p.g?"Contém glúten":"Sem glúten na receita"}</span>${p.a.map(a=>`<span>Contém ${a}</span>`).join("")}</div><p class="note">${AVISO}</p><div class="pr"><b>${R(p.p)}</b><button class="btn" id="da">Adicionar à sacola</button></div>`;
$("#da").onclick=()=>{add(i);$("#dd").close()};$("#dd").showModal()}
function tot(){return Object.entries(cart).reduce((s,[i,q])=>s+P(i).p*q,0)}
function msg(){const l=Object.entries(cart).map(([i,q])=>`• ${q}x ${P(i).n} (${R(P(i).p)} cada = ${R(P(i).p*q)})`),d=$("#dt").value?$("#dt").value.split("-").reverse().join("/"):"a combinar";
return `Olá! Gostaria de fazer um pedido para RETIRADA no local:\n\n${l.join("\n")}\n\nTotal: ${R(tot())}\nNome: ${$("#nm").value||"-"}\nRetirada: ${d}${$("#hr").value?" às "+$("#hr").value:""}${$("#ob").value?"\nObs: "+$("#ob").value:""}`}
function draw(){cart=Object.fromEntries(Object.entries(cart).filter(([,q])=>q>0));S("cart",cart);const e=Object.entries(cart);
$("#cc").textContent=e.reduce((s,[,q])=>s+q,0);
$("#its").innerHTML=e.length?e.map(([i,q])=>{const p=P(i);return `<div class="it"><span>${p.n}<br><small>${q>1?`${q} × ${R(p.p)} = `:""}<b>${R(p.p*q)}</b></small></span><span class="q"><button data-i="${i}" data-d="-1" aria-label="Remover um ${p.n}">−</button>${q}<button data-i="${i}" data-d="1" aria-label="Adicionar um ${p.n}">+</button></span></div>`}).join(""):"<p class='note'>Sua sacola está vazia.</p>";
$$("#its button").forEach(b=>b.onclick=()=>{cart[b.dataset.i]+=+b.dataset.d;draw()});
$("#tt").textContent=R(tot());upd()}
function upd(){const ok=Object.keys(cart).length&&$("#nm").value.trim()&&$("#dt").value;$("#sd").classList.toggle("off",!ok);$("#sd").setAttribute("aria-disabled",!ok);$("#sd").href=ok?wl(msg()):"#"}
$("#sd").addEventListener("click",()=>{if($("#sd").classList.contains("off"))return;Object.entries(cart).forEach(([i,q])=>pop[i]=(pop[i]||0)+q);S("pop",pop);cart={};setTimeout(()=>{draw();vitrine()},400)});
["#nm","#dt","#hr","#ob"].forEach(s=>$(s).addEventListener("input",upd));
const m=new Date();m.setDate(m.getDate()+2);$("#dt").min=m.toISOString().slice(0,10);
$("#cb").onclick=()=>$("#dr").showModal();$$("[data-x]").forEach(b=>b.onclick=()=>b.closest("dialog").close());
$$("dialog").forEach(d=>d.addEventListener("click",e=>{if(e.target===d)d.close()}));
function aba(n){$("#p1").hidden=n!=1;$("#p2").hidden=n!=2;$("#t1").classList.toggle("f",n==1);$("#t2").classList.toggle("f",n==2)}$("#t1").onclick=()=>aba(1);$("#t2").onclick=()=>aba(2);
$("#gal").innerHTML=FOTOS.map((f,i)=>`<button class="gf" data-g="${i}" aria-label="Ampliar foto: ${f.a}"><img src="${f.s}" alt="${f.a}" loading="lazy"></button>`).join("");
$$("[data-g]").forEach(b=>b.onclick=()=>{const f=FOTOS[b.dataset.g];$("#lbi").src=f.s;$("#lbi").alt=f.a;$("#lbt").textContent=f.a;$("#lb").showModal()});
vitrine();draw();
