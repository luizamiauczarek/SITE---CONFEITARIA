<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#fff7f6">
<link rel="icon" href="fotos/logo.png">
<title>Forninho da Lili · Confeitaria artesanal</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Dancing+Script:wght@600;700&family=Lato:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="estilo.css">
</head>
<body>
<a class="skip" href="#cardapio">Pular para o cardápio</a>
<div class="top">Não fazemos entrega · Retirada no nosso endereço · Encomendas com 2 dias de antecedência</div>
<header><div class="wrap nav">
<a class="logo" href="#inicio"><img class="mark" src="fotos/logo.png" alt=""><span>Forninho da Lili</span></a>
<nav class="links" aria-label="Principal"><a href="#como">Como pedir</a><a href="#cardapio">Cardápio</a><a href="#galeria">Fotos</a><a href="#sobre">Sobre</a><a href="#retirada">Retirada</a><a href="#pagamento">Pix</a></nav>
<div class="tools" role="group" aria-label="Acessibilidade e sacola">
<button class="ib" id="fm" aria-label="Diminuir letra">A−</button><button class="ib" id="fp" aria-label="Aumentar letra">A+</button>
<select id="th" aria-label="Tema de cores"><option value="auto">Automático</option><option value="light">Claro</option><option value="dark">Escuro</option><option value="contrast">Alto contraste</option></select>
<button class="ib" id="cb" aria-label="Abrir sacola">🛍️ <span class="cnt" id="cc" aria-live="polite">0</span></button>
</div></div></header>

<main id="main">
<div class="wrap hero" id="inicio"><div><span class="eyebrow">Confeitaria artesanal</span><h1>Forninho da Lili</h1>
<p class="lema">Doces feitos à mão, com carinho</p>
<p>Pequenas fornadas, ingredientes selecionados e cuidado em cada detalhe. Escolha, monte a sacola e envie o pedido pelo WhatsApp. A retirada é feita aqui, com a gente.</p><br>
<a class="btn" href="#cardapio">Ver cardápio</a><a class="btn o" href="#como">Como pedir</a></div><div class="art"><img src="fotos/embalagens.jpg" alt="Embalagens com laço rosa e potinhos de vidro com biscoitos e brownies, com o selo do Forninho da Lili"></div></div>

<div class="wrap"><div class="alert" role="note"><b>Atenção:</b> o Forninho da Lili <b>não faz entregas</b>. Todos os pedidos são <b>retirados no endereço da confeiteira</b>, em data e horário combinados.</div></div>

<section class="sec" id="como"><div class="wrap"><h2>Pedir é simples</h2><p class="sub">Quatro passos, sem cadastro.</p>
<ol class="steps"><li><b>1</b>Escolha os doces no cardápio</li><li><b>2</b>Abra a sacola e informe nome e data de retirada</li><li><b>3</b>Envie o pedido pelo WhatsApp</li><li><b>4</b>Pague por Pix e retire no local</li></ol></div></section>

<section class="sec" id="cardapio"><div class="wrap"><h2>Cardápio</h2><p class="sub">Toque em “Detalhes” para ver ingredientes, glúten e alergênicos de cada doce.</p>
<div class="cats" id="cats"></div></div></section>
<div id="pops"></div><div id="secs"></div>
<section class="sec" id="galeria"><div class="wrap"><h2>Um pouquinho do nosso forninho</h2><p class="sub">Toque em uma foto para ver maior.</p><div class="galeria" id="gal"></div></div></section>

<section id="sobre"><div class="wrap about"><div class="art" id="eu"><img src="fotos/logo.png" alt="Logo do Forninho da Lili: menina confeiteira de avental rosa segurando um bolo"></div>
<div><span class="eyebrow">Quem faz</span><h2>A história do Forninho da Lili</h2>
<p>O Forninho da Lili nasceu de um sonho que, com carinho, dedicação e muito amor, ganhou vida.</p>
<p>Mais do que doces, queremos transformar pequenos momentos em memórias especiais. Que cada delícia leve consigo a alegria de uma comemoração, o carinho de um gesto ou aquele aconchego que o coração procura nos dias mais difíceis.</p>
<p>Porque acreditamos que, às vezes, um pedacinho de doçura é tudo o que precisamos para tornar o dia mais leve, o momento mais bonito e a vida um pouquinho mais doce. 🍰✨</p>
<p class="fim">Forninho da Lili: feito com amor para adoçar momentos e criar memórias. 💕</p>
<p class="assina">Com carinho, Dani</p></div></div></section>

<section class="sec" id="retirada"><div class="wrap"><h2>Onde retirar</h2><p class="sub">Retirada somente no endereço abaixo. Não há entrega.</p>
<div class="map"><iframe id="mp" title="Mapa em satélite do local de retirada" loading="lazy"></iframe><div class="fach" id="fa"></div></div><br>
<div class="info"><div><h3>📍 Endereço</h3><p id="ad"></p><p><a id="ml" href="#" target="_blank" rel="noopener">Abrir no Google Maps (satélite)</a></p></div><div><h3>🕘 Horários</h3><p>Seg a Sex: 10h às 18h<br>Sábado: 9h às 13h</p></div><div><h3>💬 Combinado</h3><p>Confirmamos data e horário pelo WhatsApp após o pedido.</p></div></div></div></section>

<section class="sec" id="pagamento"><div class="wrap"><h2>Pagamento por Pix</h2><p class="sub">Combinado pelo WhatsApp após a confirmação do pedido.</p>
<div class="pix"><p class="note">Chave Pix · <span id="pn"></span></p><div class="key" id="pk"></div><button class="btn" data-copy>Copiar chave Pix</button><p class="note" role="status" id="pm"></p></div></div></section>
</main>

<footer><div class="wrap"><div class="fg">
<div><a class="logo" href="#inicio" style="margin-bottom:8px"><img class="mark" src="fotos/logo.png" alt=""><span>Forninho da Lili</span></a><p>Confeitaria artesanal feita com carinho, sob encomenda.</p></div>
<div><h4>Navegue</h4><a href="#como">Como pedir</a><a href="#cardapio">Cardápio</a><a href="#galeria">Fotos</a><a href="#sobre">Sobre</a><a href="#retirada">Retirada</a><a href="#pagamento">Pix</a></div>
<div><h4>Atendimento</h4><p>Seg a Sex: 10h às 18h</p><p>Sábado: 9h às 13h</p><p><b>Sem entrega</b> · só retirada</p></div>
<div><h4>Contato</h4><a id="fw" href="#" target="_blank" rel="noopener">WhatsApp</a><a href="#" target="_blank" rel="noopener">Instagram</a><p id="fad"></p></div>
</div><div class="copy">© 2026 Forninho da Lili · Feito com carinho pela Dani</div></div></footer>

<a class="wa" id="fb" href="#" target="_blank" rel="noopener" aria-label="Falar no WhatsApp">💬</a>

<dialog id="lb" aria-label="Foto ampliada"><div class="dp"><div class="dh"><span></span><button class="ib" data-x aria-label="Fechar foto">✕</button></div><img id="lbi" alt=""><p class="note" id="lbt"></p></div></dialog>

<dialog id="dd" aria-labelledby="dn"><div class="dp"><div class="dh"><h2 id="dn"></h2><button class="ib" data-x aria-label="Fechar">✕</button></div><div id="db"></div></div></dialog>

<dialog class="dr" id="dr" aria-labelledby="dt0"><div class="dp">
<div class="dh"><h3 id="dt0">Sua sacola</h3><button class="ib" data-x aria-label="Fechar sacola">✕</button></div>
<div class="tabs"><button class="sm f" id="t1">Pedido</button><button class="sm" id="t2">Pix</button></div>
<div id="p1"><div id="its"></div>
<div class="tot"><span>Total</span><span id="tt">R$ 0,00</span></div><br>
<label>Seu nome<input id="nm" autocomplete="name"></label><br>
<label>Data de retirada<input id="dt" type="date"></label><br>
<label>Horário<input id="hr" type="time"></label><br>
<label>Observações<textarea id="ob" rows="2" placeholder="Recado, restrição alimentar..."></textarea></label><br>
<p class="note">Sem entrega: retire no endereço da confeiteira. Pedidos com 2 dias de antecedência. Sua sacola fica salva neste aparelho.</p><br>
<a class="btn send off" id="sd" href="#" target="_blank" rel="noopener" aria-disabled="true">Enviar pedido pelo WhatsApp</a></div>
<div id="p2" hidden><div class="pix" style="border:0;padding:0"><p>Chave Pix · <span class="pn"></span></p><div class="key pk"></div><button class="btn" data-copy>Copiar chave Pix</button><p class="note" role="status" id="pm2"></p></div></div>
</div></dialog>

<script src="script.js"></script>
</body>
</html>
